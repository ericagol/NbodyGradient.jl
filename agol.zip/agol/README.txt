To use nbody.c please place all the files in the same directory and type ’make’ in that directory.  

To run an N-body simulation please type ‘./nbody a b’.  a is the time step in years and b is the runtime in years.
